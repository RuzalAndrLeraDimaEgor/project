﻿namespace Cafe_Project
{
    partial class orders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(orders));
            this.tableOrder = new System.Windows.Forms.DataGridView();
            this.number_order = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name_cafe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.contentb = new System.Windows.Forms.Button();
            this.summ_tb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tableOrder)).BeginInit();
            this.SuspendLayout();
            // 
            // tableOrder
            // 
            this.tableOrder.AllowUserToAddRows = false;
            this.tableOrder.AllowUserToDeleteRows = false;
            this.tableOrder.BackgroundColor = System.Drawing.Color.Linen;
            this.tableOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableOrder.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.number_order,
            this.name_cafe,
            this.total,
            this.date});
            this.tableOrder.Location = new System.Drawing.Point(29, 88);
            this.tableOrder.Name = "tableOrder";
            this.tableOrder.Size = new System.Drawing.Size(583, 292);
            this.tableOrder.TabIndex = 0;
            // 
            // number_order
            // 
            this.number_order.DataPropertyName = "number";
            this.number_order.HeaderText = "Номер заказа";
            this.number_order.Name = "number_order";
            this.number_order.Width = 70;
            // 
            // name_cafe
            // 
            this.name_cafe.DataPropertyName = "restname";
            this.name_cafe.HeaderText = "Ресторан";
            this.name_cafe.Name = "name_cafe";
            this.name_cafe.ReadOnly = true;
            this.name_cafe.Width = 200;
            // 
            // total
            // 
            this.total.DataPropertyName = "summa";
            this.total.HeaderText = "Сумма";
            this.total.Name = "total";
            this.total.ReadOnly = true;
            this.total.Width = 120;
            // 
            // date
            // 
            this.date.DataPropertyName = "date";
            this.date.HeaderText = "Дата";
            this.date.Name = "date";
            this.date.ReadOnly = true;
            this.date.Width = 150;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.Location = new System.Drawing.Point(23, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 33);
            this.label1.TabIndex = 6;
            this.label1.Text = "Заказы";
            // 
            // contentb
            // 
            this.contentb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.contentb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.contentb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.contentb.FlatAppearance.BorderSize = 2;
            this.contentb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.contentb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.contentb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.contentb.Location = new System.Drawing.Point(29, 386);
            this.contentb.Name = "contentb";
            this.contentb.Size = new System.Drawing.Size(224, 41);
            this.contentb.TabIndex = 30;
            this.contentb.Text = "Информация о заказе";
            this.contentb.UseVisualStyleBackColor = true;
            this.contentb.Click += new System.EventHandler(this.contentb_Click);
            // 
            // summ_tb
            // 
            this.summ_tb.Location = new System.Drawing.Point(395, 386);
            this.summ_tb.Multiline = true;
            this.summ_tb.Name = "summ_tb";
            this.summ_tb.Size = new System.Drawing.Size(217, 41);
            this.summ_tb.TabIndex = 31;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(302, 392);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 26);
            this.label2.TabIndex = 32;
            this.label2.Text = "Сумма:";
            // 
            // orders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.ClientSize = new System.Drawing.Size(657, 461);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.summ_tb);
            this.Controls.Add(this.contentb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tableOrder);
            this.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "orders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Мои заказы";
            ((System.ComponentModel.ISupportInitialize)(this.tableOrder)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView tableOrder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button contentb;
        private System.Windows.Forms.TextBox summ_tb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn number_order;
        private System.Windows.Forms.DataGridViewTextBoxColumn name_cafe;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
    }
}