﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class address_rest : Form
    {
        public address_rest()
        {
            InitializeComponent();
            Response_to_server();
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }

        [JsonObject(MemberSerialization.OptIn)]
        struct addresses
        {
            [JsonProperty("restname")]
            public string restname { get; set; }
            [JsonProperty("address")]
            public string addr { get; set; }
        }
        private class address_data
        {
            public string restname { get; set; }
            public string address { get; set; }
        }
        List<address_data> address_list = new List<address_data>();
        private string error;

        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create("https://localhost/addresses.php");
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                address_list.Clear();
                if (error != "error")
                {
                    addresses[] objdata = JsonConvert.DeserializeObject<addresses[]>(obj["data"].ToString());
                    foreach (addresses myJsonObj in objdata)
                    {
                        address_data newAddr = new address_data();
                        newAddr.restname = myJsonObj.restname;
                        newAddr.address = myJsonObj.addr;
                        address_list.Add(newAddr);
                    }
                    tableAddress.DataSource = address_list;
                }
            }
            catch (Exception ex)
            {
                error = "error";
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
    }
}
