﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class stat : Form
    {
        public stat()
        {
            InitializeComponent();
            Response_to_server();
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }

        [JsonObject(MemberSerialization.OptIn)]
        struct rate_data
        {
            [JsonProperty("restname")]
            public string restname { get; set; }
            [JsonProperty("summa")]
            public decimal summa { get; set; }
            [JsonProperty("count")]
            public int count { get; set; }
        }
        private class rate
        {
            public int count { get; set; }
            public string restname { get; set; }
            public decimal summa { get; set; }
        }
        List<rate> rate_list = new List<rate>();

        private string error;

        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/search.php?search=stat&session_id={0}", enter.session_id));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                rate_list.Clear();
                if (error != "null")
                {
                    rate_data[] objdata = JsonConvert.DeserializeObject<rate_data[]>(obj["data"].ToString());
                    foreach (rate_data myJsonObj in objdata)
                    {
                        rate newRate = new rate();
                        newRate.restname = myJsonObj.restname;
                        newRate.count = myJsonObj.count;
                        newRate.summa = myJsonObj.summa;
                        rate_list.Add(newRate);
                    }
                    tableRate.DataSource = rate_list;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
    }
}
