﻿namespace Cafe_Project
{
    partial class order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(order));
            this.label1 = new System.Windows.Forms.Label();
            this.take_ord = new System.Windows.Forms.Button();
            this.dishesbox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.restbox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.counttb = new System.Windows.Forms.TextBox();
            this.priceb = new System.Windows.Forms.Button();
            this.pricetb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.numcard = new System.Windows.Forms.TextBox();
            this.chooseb = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.volumebox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.Location = new System.Drawing.Point(27, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 33);
            this.label1.TabIndex = 6;
            this.label1.Text = "Оформление заказа";
            // 
            // take_ord
            // 
            this.take_ord.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.take_ord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.take_ord.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.take_ord.FlatAppearance.BorderSize = 2;
            this.take_ord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.take_ord.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.take_ord.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.take_ord.Location = new System.Drawing.Point(33, 405);
            this.take_ord.Name = "take_ord";
            this.take_ord.Size = new System.Drawing.Size(357, 41);
            this.take_ord.TabIndex = 7;
            this.take_ord.Text = "Сделать заказ";
            this.take_ord.UseVisualStyleBackColor = true;
            this.take_ord.Click += new System.EventHandler(this.take_ord_Click);
            // 
            // dishesbox
            // 
            this.dishesbox.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dishesbox.FormattingEnabled = true;
            this.dishesbox.Location = new System.Drawing.Point(141, 144);
            this.dishesbox.Name = "dishesbox";
            this.dishesbox.Size = new System.Drawing.Size(249, 27);
            this.dishesbox.TabIndex = 2;
            this.dishesbox.SelectedIndexChanged += new System.EventHandler(this.dishesbox_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(28, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 26);
            this.label3.TabIndex = 10;
            this.label3.Text = "Блюдо:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(28, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 26);
            this.label4.TabIndex = 11;
            this.label4.Text = "Ресторан:";
            // 
            // restbox
            // 
            this.restbox.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.restbox.FormattingEnabled = true;
            this.restbox.Location = new System.Drawing.Point(141, 92);
            this.restbox.Name = "restbox";
            this.restbox.Size = new System.Drawing.Size(249, 27);
            this.restbox.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(28, 250);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(209, 26);
            this.label5.TabIndex = 13;
            this.label5.Text = "Введите количество:";
            // 
            // counttb
            // 
            this.counttb.Location = new System.Drawing.Point(243, 249);
            this.counttb.Multiline = true;
            this.counttb.Name = "counttb";
            this.counttb.Size = new System.Drawing.Size(147, 27);
            this.counttb.TabIndex = 4;
            // 
            // priceb
            // 
            this.priceb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.priceb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.priceb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.priceb.FlatAppearance.BorderSize = 2;
            this.priceb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.priceb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.priceb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.priceb.Location = new System.Drawing.Point(33, 300);
            this.priceb.Name = "priceb";
            this.priceb.Size = new System.Drawing.Size(189, 41);
            this.priceb.TabIndex = 15;
            this.priceb.Text = "Рассчитать цену";
            this.priceb.UseVisualStyleBackColor = true;
            this.priceb.Click += new System.EventHandler(this.priceb_Click);
            // 
            // pricetb
            // 
            this.pricetb.Location = new System.Drawing.Point(243, 300);
            this.pricetb.Multiline = true;
            this.pricetb.Name = "pricetb";
            this.pricetb.Size = new System.Drawing.Size(147, 41);
            this.pricetb.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(28, 363);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 26);
            this.label2.TabIndex = 17;
            this.label2.Text = "Номер карты:";
            // 
            // numcard
            // 
            this.numcard.Location = new System.Drawing.Point(176, 363);
            this.numcard.Multiline = true;
            this.numcard.Name = "numcard";
            this.numcard.Size = new System.Drawing.Size(214, 27);
            this.numcard.TabIndex = 6;
            // 
            // chooseb
            // 
            this.chooseb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.chooseb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chooseb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.chooseb.FlatAppearance.BorderSize = 2;
            this.chooseb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chooseb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chooseb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chooseb.Location = new System.Drawing.Point(396, 90);
            this.chooseb.Name = "chooseb";
            this.chooseb.Size = new System.Drawing.Size(129, 29);
            this.chooseb.TabIndex = 19;
            this.chooseb.Text = "Выбрать";
            this.chooseb.UseVisualStyleBackColor = true;
            this.chooseb.Click += new System.EventHandler(this.chooseb_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(28, 189);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 26);
            this.label6.TabIndex = 21;
            this.label6.Text = "Объем:";
            // 
            // volumebox
            // 
            this.volumebox.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.volumebox.FormattingEnabled = true;
            this.volumebox.Location = new System.Drawing.Point(141, 191);
            this.volumebox.Name = "volumebox";
            this.volumebox.Size = new System.Drawing.Size(249, 27);
            this.volumebox.TabIndex = 3;
            // 
            // order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.ClientSize = new System.Drawing.Size(540, 480);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.volumebox);
            this.Controls.Add(this.chooseb);
            this.Controls.Add(this.numcard);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pricetb);
            this.Controls.Add(this.priceb);
            this.Controls.Add(this.counttb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.restbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dishesbox);
            this.Controls.Add(this.take_ord);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "order";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Сделать заказ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button take_ord;
        private System.Windows.Forms.ComboBox dishesbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox restbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox counttb;
        private System.Windows.Forms.Button priceb;
        private System.Windows.Forms.TextBox pricetb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox numcard;
        private System.Windows.Forms.Button chooseb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox volumebox;
    }
}