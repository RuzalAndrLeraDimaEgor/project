﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Security; 

namespace Cafe_Project
{
    public partial class menu : Form
    {
        int position;
        public menu()
        {
            InitializeComponent();
            Response_to_server();
            position = 0;
            if (error != "error")
            {
                refresh();
                create_menu();
                button_menu();
                prev.Hide();
            }
        }

        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }

        [JsonObject(MemberSerialization.OptIn)]
        struct dish_menu
        {
            [JsonProperty("dname")]
            public string dname { get; set; }
            [JsonProperty("cap")]
            public decimal cap { get; set; }
        }
        private class dishes
        {
            public string dname { get; set; }
            public decimal cap { get; set; }
        }
        List<dishes> dish = new List<dishes>();
        private string error;
        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create("https://localhost/search.php?search=menu");
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                dish.Clear();
                if (error != "error")
                {
                    dish_menu[] objdata = JsonConvert.DeserializeObject<dish_menu[]>(obj["data"].ToString());
                    foreach (dish_menu myJsonObj in objdata)
                    {
                        dishes newDish = new dishes();
                        newDish.dname = myJsonObj.dname;
                        newDish.cap = myJsonObj.cap;
                        dish.Add(newDish);
                    }
                }
            }
            catch (Exception ex)
            {
                error = "error";
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }

        private void button_menu()
        {
            prev.Show();
            next.Show();
            if (dish.Count == 0 || dish.Count == 1)
            {
                prev.Hide();
                next.Hide();
            }
            else
            {
                if (position - 1 < 0)
                {
                    prev.Hide();
                    next.Show();
                }
                else
                    prev.Show();
                if (position + 5 >= dish.Count - 1)
                {
                    prev.Show();
                    next.Hide();
                }
            }
            
        }

        private void refresh()
        {
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
            label10.Text = "";
            label11.Text = "";
            label12.Text = "";
            label13.Text = "";
            linkLabel1.Text = "";
            linkLabel2.Text = "";
            linkLabel3.Text = "";
            linkLabel4.Text = "";
            linkLabel5.Text = "";
        }
        private void create_menu()
        {
            int i = 0;
            if (dish.Count - position >= 5)
            {
                label4.Text = dish[i + position].dname;
                label9.Text = Convert.ToString(dish[i + position].cap);
                label5.Text = dish[i + 1+position].dname;
                label10.Text = Convert.ToString(dish[i + 1 + position].cap);
                label6.Text = dish[i + 2 + position].dname;
                label11.Text = Convert.ToString(dish[i + 2 + position].cap);
                label7.Text = dish[i + 3 + position].dname;
                label12.Text = Convert.ToString(dish[i + 3 + position].cap);
                label8.Text = dish[i + 4 + position].dname;
                label13.Text = Convert.ToString(dish[i + 4 + position].cap);
                linkLabel1.Text = "Узнать";
                linkLabel2.Text = "Узнать";
                linkLabel3.Text = "Узнать";
                linkLabel4.Text = "Узнать";
                linkLabel5.Text = "Узнать";
            }
            else
            {
                if (dish.Count  > i+position)
                {
                    label4.Text = dish[i + position].dname;
                    label9.Text = Convert.ToString(dish[i + position].cap);
                    linkLabel1.Text = "Узнать";
                }
                if (dish.Count > i + 1 + position)
                {
                    label5.Text = dish[i + 1 + position].dname;
                    label10.Text = Convert.ToString(dish[i + 1 + position].cap);
                    linkLabel2.Text = "Узнать";
                }
                if (dish.Count > i + 2 + position)
                {
                    label6.Text = dish[i + 2 + position].dname;
                    label11.Text = Convert.ToString(dish[i + 2 + position].cap);
                    linkLabel3.Text = "Узнать";
                }
                if (dish.Count > i + 3 + position)
                {
                    label7.Text = dish[i + 3 + position].dname;
                    label12.Text = Convert.ToString(dish[i + 3 + position].cap);
                    linkLabel4.Text = "Узнать";
                }
                if (dish.Count > i + 4 + position)
                {
                    label8.Text = dish[i + 4 + position].dname;
                    label13.Text = Convert.ToString(dish[i + 4 + position].cap);
                    linkLabel5.Text = "Узнать";
                }
                
            }
        }
        
            

        private void search_dish_Click(object sender, EventArgs e)
        {
            search_dish sdf = new search_dish();
            sdf.ShowDialog();
        }

        private void closeb_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void prev_Click(object sender, EventArgs e)
        {
            position -= 5;
            button_menu();
            refresh();
            create_menu();
            page_info.Text = Convert.ToString("~" + (position / 5 + 1) + "~");
        }

        private void next_Click(object sender, EventArgs e)
        {
            position += 5;
            button_menu();
            refresh();
            create_menu();
            page_info.Text = Convert.ToString("~" + (position / 5 + 1) + "~");
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            price pf = new price(label4.Text);
            pf.ShowDialog();
        }
        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            price pf = new price(label5.Text);
            pf.ShowDialog();
        }
        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            price pf = new price(label6.Text);
            pf.ShowDialog();
        }
        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            price pf = new price(label7.Text);
            pf.ShowDialog();
        }
        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            price pf = new price(label8.Text);
            pf.ShowDialog();
        }

        
    }
}
