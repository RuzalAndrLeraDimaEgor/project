﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class all_order : Form
    {
        public all_order()
        {
            InitializeComponent();
            Response_to_server();
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }

        [JsonObject(MemberSerialization.OptIn)]
        struct orders_data
        {
            [JsonProperty("fio")]
            public string fio { get; set; }
            [JsonProperty("restname")]
            public string restname { get; set; }
            [JsonProperty("summa")]
            public decimal summa { get; set; }
            [JsonProperty("date")]
            public DateTime date { get; set; }
        }
        private class order_data
        {
            public string fio { get; set; }
            public string restname { get; set; }
            public decimal summa { get; set; }
            public DateTime date { get; set; }
        }
        List<order_data> order_list = new List<order_data>();
       
        private string error;

        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/order.php?select=all_orders&session_id={0}",enter.session_id));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                order_list.Clear();
                if (error != "null")
                {
                    orders_data[] objdata = JsonConvert.DeserializeObject<orders_data[]>(obj["data"].ToString());
                    foreach (orders_data myJsonObj in objdata)
                    {
                        order_data newOrder = new order_data();
                        newOrder.fio = myJsonObj.fio;
                        newOrder.restname = myJsonObj.restname;
                        newOrder.summa = myJsonObj.summa;
                        newOrder.date = myJsonObj.date;
                        order_list.Add(newOrder);
                    }
                    tableOrders.DataSource = order_list;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
    }
}
