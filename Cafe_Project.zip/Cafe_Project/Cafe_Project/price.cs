﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class price : Form
    {
        private int position;
        private string dishname;
        public price(string dish_name)
        {
            dishname = dish_name;
            InitializeComponent();
            position = 0;
            Response_to_server();
            refresh();
            if (error != "null")
            {
                show_list();
                if (enter.role == "employee")
                {
                    deleteitem.Visible = true;
                    saveitem.Visible = true;
                    deleteitem.Enabled = true;
                    saveitem.Enabled = true;
                }
                else
                {
                    deleteitem.Visible = false;
                    saveitem.Visible = false;
                    deleteitem.Enabled = false;
                    saveitem.Enabled = false;
                }
            }
        }
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct data_dish
        {
            [JsonProperty("dname")]
            public string dname { get; set; }
            [JsonProperty("price")]
            public decimal price { get; set; }
            [JsonProperty("cap")]
            public decimal cap { get; set; }
            [JsonProperty("restname")]
            public string restname { get; set; }
        }

        private class dishes
        {
            public string dname { get; set; }
            public decimal cap { get; set; }
            public decimal price { get; set; }
            public string restname { get; set; }
        }

        List<dishes> dish_list = new List<dishes>();
        private void refresh()
        {
            previtem.Enabled = true;
            firstitem.Enabled = true;
            previtem.Visible = true;
            firstitem.Visible = true;
            nextitem.Visible = true;
            lastitem.Visible = true;
            nextitem.Enabled = true;
            lastitem.Enabled = true;
            if (dish_list.Count == 0)
            {
                previtem.Visible = false;
                firstitem.Visible = false;
                nextitem.Visible = false;
                lastitem.Visible = false;
                deleteitem.Visible = false;
                saveitem.Visible = false;
            }
            else if (dish_list.Count == 1)
            {
                previtem.Visible = false;
                firstitem.Visible = false;
                nextitem.Visible = false;
                lastitem.Visible = false;
                if (enter.role == "employee")
                {
                    deleteitem.Visible = true;
                    saveitem.Visible = true;
                    deleteitem.Enabled = true;
                    saveitem.Enabled = true;
                }
            }
            else
            {
                if (position - 1 < 0)
                {
                    previtem.Visible = false;
                    firstitem.Visible = false;
                    nextitem.Enabled = true;
                    lastitem.Enabled = true;
                    nextitem.Visible = true;
                    lastitem.Visible = true;
                }
                else
                {
                    previtem.Visible = true;
                    firstitem.Visible = true;
                    previtem.Enabled = true;
                    firstitem.Enabled = true;
                }
                if (position == dish_list.Count - 1)
                {
                    previtem.Enabled = true;
                    firstitem.Enabled = true;
                    previtem.Visible = true;
                    firstitem.Visible = true;
                    nextitem.Visible = false;
                    lastitem.Visible = false;
                }
            }
        }


        private string error;
        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/search.php?search=price&dish_name={0}",dishname));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                dish_list.Clear();
                if (error != "null")
                {
                    data_dish[] objdata = JsonConvert.DeserializeObject<data_dish[]>(obj["data"].ToString());
                    foreach (data_dish myJsonObj in objdata)
                    {
                        dishes newDish = new dishes();
                        newDish.dname = myJsonObj.dname;
                        newDish.price = myJsonObj.price;
                        newDish.cap = myJsonObj.cap;
                        newDish.restname = myJsonObj.restname;
                        dish_list.Add(newDish);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }

        private void show_list()
        {
            name_dishtb.Text = dish_list[position].dname;
            restb.Text = dish_list[position].restname;
            pricetb.Text = Convert.ToString(dish_list[position].price);
            volumetb.Text = Convert.ToString(dish_list[position].cap);
        }
        private void Response_to_server_delete()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/delete.php?delete=price&dish_name={0}&volume={1}&session_id={2}&restname={3}", name_dishtb.Text, volumetb.Text, enter.session_id, restb.Text));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                if (error != "error")
                {
                    MessageBox.Show("Удалено!");
                    if (position == dish_list.Count - 1)
                        position--;
                    Response_to_server();
                    refresh();
                    show_list();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private void Response_to_server_save()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/update.php?update=price&dish_name={0}&volume={1}&session_id={2}&price={3}&restname={4}", name_dishtb.Text, volumetb.Text, enter.session_id, pricetb.Text, restb.Text));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                if (error != "error")
                {
                    MessageBox.Show("Сохранено!");
                    Response_to_server();
                    refresh();
                    show_list();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private void deleteitem_Click(object sender, EventArgs e)
        {
            Response_to_server_delete();
        }

        private void saveitem_Click(object sender, EventArgs e)
        {
            if (pricetb.Text.Trim(' ') != "")
                Response_to_server_save();
            else
                MessageBox.Show("Нельзя сохранить.Введите цену!");
        }

        private void firstitem_Click(object sender, EventArgs e)
        {
            position = 0;
            refresh();
            show_list();
        }

        private void previtem_Click(object sender, EventArgs e)
        {
            position --;
            refresh();
            show_list();
        }

        private void nextitem_Click(object sender, EventArgs e)
        {
            position ++;
            refresh();
            show_list();
        }

        private void lastitem_Click(object sender, EventArgs e)
        {
            position = dish_list.Count - 1;
            refresh();
            show_list();
        }
    }
}
