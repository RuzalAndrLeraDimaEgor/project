﻿namespace Cafe_Project
{
    partial class main
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.menub = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.addressesb = new System.Windows.Forms.Button();
            this.pcb = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // menub
            // 
            this.menub.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.menub.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menub.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.menub.FlatAppearance.BorderSize = 2;
            this.menub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menub.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menub.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.menub.Location = new System.Drawing.Point(245, 115);
            this.menub.Name = "menub";
            this.menub.Size = new System.Drawing.Size(193, 41);
            this.menub.TabIndex = 0;
            this.menub.Text = "Меню";
            this.menub.UseVisualStyleBackColor = true;
            this.menub.Click += new System.EventHandler(this.menub_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.Location = new System.Drawing.Point(112, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(482, 45);
            this.label1.TabIndex = 3;
            this.label1.Text = "Сеть    Ресторанов     Andiamo ";
            // 
            // addressesb
            // 
            this.addressesb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.addressesb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addressesb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.addressesb.FlatAppearance.BorderSize = 2;
            this.addressesb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addressesb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addressesb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.addressesb.Location = new System.Drawing.Point(245, 162);
            this.addressesb.Name = "addressesb";
            this.addressesb.Size = new System.Drawing.Size(193, 41);
            this.addressesb.TabIndex = 4;
            this.addressesb.Text = "Адреса";
            this.addressesb.UseVisualStyleBackColor = true;
            this.addressesb.Click += new System.EventHandler(this.addressesb_Click);
            // 
            // pcb
            // 
            this.pcb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.pcb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pcb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.pcb.FlatAppearance.BorderSize = 2;
            this.pcb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pcb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pcb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pcb.Location = new System.Drawing.Point(245, 209);
            this.pcb.Name = "pcb";
            this.pcb.Size = new System.Drawing.Size(193, 41);
            this.pcb.TabIndex = 5;
            this.pcb.Text = "Личный кабинет";
            this.pcb.UseVisualStyleBackColor = true;
            this.pcb.Click += new System.EventHandler(this.pcb_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(706, 341);
            this.Controls.Add(this.pcb);
            this.Controls.Add(this.addressesb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menub);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Сеть Ресторанов Andiamo";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.enter_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button menub;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button addressesb;
        private System.Windows.Forms.Button pcb;

    }
}

