﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class enter : Form
    {
        private string error;
        public static string session_id;
        public static string role;
        private bool flag = false;
        public enter()
        {
            InitializeComponent();
        }

        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }

        [JsonObject(MemberSerialization.OptIn)]
        struct user
        {
            [JsonProperty("session_id")]
            public string session_id { get; set; }
            [JsonProperty("role")]
            public string role { get; set; }
        }

        
        private void Response_to_server()
        {
            try
            {
                //https - данные передаются поверх протоколов ssl и tls 
                //для него исп проверенный сертификат 
                //но тк сертификата у нас нет, то принимаем любой серт, если даже его нет
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                //создаем запрос к серверу, куда передаем данные (почта и пароль)
                WebRequest request = WebRequest.Create(String.Format("https://localhost/login.php?email={0}&password={1}",emailtb.Text,passtb.Text));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                //получаем ответ от сервера
                var responseFromServer = reader.ReadToEnd();
                //данные необходимо распарсить, т.к. от сервера они приходят в виде json - массива
                // ассоциативный массив: ключ- значение
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                //первая часть включает в себя ключ type: в котором есть ключ error со значением ошибки
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                if (error != "error")
                {
                    //вторая часть вкл в себя - data: ключи session_id и role
                    user[] objdata = JsonConvert.DeserializeObject<user[]>(obj["data"].ToString());
                    foreach (user myJsonObj in objdata)
                    {
                        session_id = myJsonObj.session_id;
                        role = myJsonObj.role;
                    }
                }
            }
            catch (Exception ex)
            {
                error = "error";
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
  
        private void enter_b_Click(object sender, EventArgs e)
        {
            Response_to_server();
            if (error == "error")
            {
                MessageBox.Show("Данные введены неверно!");
                return;
            }
            main.flag = true;
            order.flag_order = false;
            this.Close();
            pc pcf = new pc();
            pcf.Show();
            
        }

        private void reg_b_Click(object sender, EventArgs e)
        {
            registration rf = new registration();
            rf.ShowDialog();
        }

        private void tomain_b_Click(object sender, EventArgs e)
        {
            this.Close();
            main mf = new main();
            mf.Show();
        }

        private void enter_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (flag)
                Application.Exit();
            else if (!main.flag)
            {
                main mf = new main();
                mf.Show();
            }
        }

    }
}
