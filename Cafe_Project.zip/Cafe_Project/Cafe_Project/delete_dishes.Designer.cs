﻿namespace Cafe_Project
{
    partial class delete_dishes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dishbox = new System.Windows.Forms.ComboBox();
            this.delete_b = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.volumebox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // dishbox
            // 
            this.dishbox.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dishbox.FormattingEnabled = true;
            this.dishbox.Location = new System.Drawing.Point(44, 79);
            this.dishbox.Name = "dishbox";
            this.dishbox.Size = new System.Drawing.Size(355, 31);
            this.dishbox.TabIndex = 41;
            this.dishbox.SelectedIndexChanged += new System.EventHandler(this.dishesbox_SelectedIndexChanged);
            // 
            // delete_b
            // 
            this.delete_b.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.delete_b.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.delete_b.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.delete_b.FlatAppearance.BorderSize = 2;
            this.delete_b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delete_b.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delete_b.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.delete_b.Location = new System.Drawing.Point(44, 188);
            this.delete_b.Name = "delete_b";
            this.delete_b.Size = new System.Drawing.Size(355, 41);
            this.delete_b.TabIndex = 45;
            this.delete_b.Text = "Удалить";
            this.delete_b.UseVisualStyleBackColor = true;
            this.delete_b.Click += new System.EventHandler(this.delete_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(40, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 23);
            this.label3.TabIndex = 44;
            this.label3.Text = "Объем:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(40, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 23);
            this.label1.TabIndex = 43;
            this.label1.Text = "Блюдо";
            // 
            // volumebox
            // 
            this.volumebox.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.volumebox.FormattingEnabled = true;
            this.volumebox.Location = new System.Drawing.Point(44, 139);
            this.volumebox.Name = "volumebox";
            this.volumebox.Size = new System.Drawing.Size(355, 31);
            this.volumebox.TabIndex = 46;
            this.volumebox.SelectedIndexChanged += new System.EventHandler(this.volumebox_SelectedIndexChanged);
            // 
            // delete_dishes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.ClientSize = new System.Drawing.Size(429, 265);
            this.Controls.Add(this.volumebox);
            this.Controls.Add(this.dishbox);
            this.Controls.Add(this.delete_b);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "delete_dishes";
            this.Text = "Удалить блюдо";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox dishbox;
        private System.Windows.Forms.Button delete_b;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox volumebox;
    }
}