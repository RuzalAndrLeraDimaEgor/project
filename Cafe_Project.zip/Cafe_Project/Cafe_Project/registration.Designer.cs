﻿namespace Cafe_Project
{
    partial class registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(registration));
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.emailtb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.passtb = new System.Windows.Forms.TextBox();
            this.phonetb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.addresstb = new System.Windows.Forms.TextBox();
            this.nametb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.reg_b = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.Info;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label4.Location = new System.Drawing.Point(50, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(421, 39);
            this.label4.TabIndex = 6;
            this.label4.Text = "Сеть    Ресторанов     Andiamo ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(53, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 23);
            this.label1.TabIndex = 7;
            this.label1.Text = "Email:";
            // 
            // emailtb
            // 
            this.emailtb.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.emailtb.Location = new System.Drawing.Point(151, 116);
            this.emailtb.Multiline = true;
            this.emailtb.Name = "emailtb";
            this.emailtb.Size = new System.Drawing.Size(261, 32);
            this.emailtb.TabIndex = 0;
            this.emailtb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(53, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 23);
            this.label2.TabIndex = 9;
            this.label2.Text = "Пароль:";
            // 
            // passtb
            // 
            this.passtb.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passtb.Location = new System.Drawing.Point(151, 160);
            this.passtb.Multiline = true;
            this.passtb.Name = "passtb";
            this.passtb.PasswordChar = '*';
            this.passtb.Size = new System.Drawing.Size(261, 32);
            this.passtb.TabIndex = 1;
            this.passtb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // phonetb
            // 
            this.phonetb.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.phonetb.Location = new System.Drawing.Point(151, 248);
            this.phonetb.Multiline = true;
            this.phonetb.Name = "phonetb";
            this.phonetb.Size = new System.Drawing.Size(261, 32);
            this.phonetb.TabIndex = 3;
            this.phonetb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(53, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 23);
            this.label3.TabIndex = 12;
            this.label3.Text = "Адрес:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(53, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 23);
            this.label5.TabIndex = 13;
            this.label5.Text = "Телефон:";
            // 
            // addresstb
            // 
            this.addresstb.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addresstb.Location = new System.Drawing.Point(151, 205);
            this.addresstb.Multiline = true;
            this.addresstb.Name = "addresstb";
            this.addresstb.Size = new System.Drawing.Size(261, 32);
            this.addresstb.TabIndex = 2;
            this.addresstb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nametb
            // 
            this.nametb.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nametb.Location = new System.Drawing.Point(151, 293);
            this.nametb.Multiline = true;
            this.nametb.Name = "nametb";
            this.nametb.Size = new System.Drawing.Size(261, 32);
            this.nametb.TabIndex = 4;
            this.nametb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(53, 293);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 23);
            this.label6.TabIndex = 16;
            this.label6.Text = "ФИО:";
            // 
            // reg_b
            // 
            this.reg_b.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.reg_b.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.reg_b.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.reg_b.FlatAppearance.BorderSize = 2;
            this.reg_b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.reg_b.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.reg_b.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.reg_b.Location = new System.Drawing.Point(166, 347);
            this.reg_b.Name = "reg_b";
            this.reg_b.Size = new System.Drawing.Size(222, 41);
            this.reg_b.TabIndex = 17;
            this.reg_b.Text = "Регистрация";
            this.reg_b.UseVisualStyleBackColor = true;
            this.reg_b.Click += new System.EventHandler(this.reg_b_Click);
            // 
            // cancel
            // 
            this.cancel.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.cancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cancel.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.cancel.FlatAppearance.BorderSize = 2;
            this.cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cancel.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cancel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cancel.Location = new System.Drawing.Point(166, 394);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(222, 41);
            this.cancel.TabIndex = 18;
            this.cancel.Text = "Отмена";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.button1_Click);
            // 
            // registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.ClientSize = new System.Drawing.Size(554, 483);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.reg_b);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.nametb);
            this.Controls.Add(this.addresstb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.phonetb);
            this.Controls.Add(this.passtb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.emailtb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "registration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Регистрация пользователя";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox emailtb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox passtb;
        private System.Windows.Forms.TextBox phonetb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox addresstb;
        private System.Windows.Forms.TextBox nametb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button reg_b;
        private System.Windows.Forms.Button cancel;
    }
}