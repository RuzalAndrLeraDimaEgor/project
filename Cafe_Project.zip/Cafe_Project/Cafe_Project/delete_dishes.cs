﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class delete_dishes : Form
    {
        public delete_dishes()
        {
            InitializeComponent();
            Response_to_server_get_dishes();
            delete_b.Hide();
            volumebox.Hide();
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }
        private string error;

        private void Response_to_server_delete()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/delete.php?delete=dish&dish_name={0}&volume={1}&session_id={2}", dishbox.Text, volumebox.Text, enter.session_id));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private bool check_data()
        {
            if (dishbox.Text.Trim(' ') == "" || volumebox.Text.Trim(' ') == "")
            {
                MessageBox.Show("Выберите данные!");
                return false;
            }
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct dish_data
        {
            [JsonProperty("dname")]
            public string dname { get; set; }
            [JsonProperty("cap")]
            public string cap { get; set; }
        }
        private class dishes
        {
            public string dname { get; set; }
            public string cap { get; set; }
        }
        List<dishes> dish_list = new List<dishes>();

        private void Response_to_server_get_dishes()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/search.php?search=dishes"));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                dish_list.Clear();
                dishbox.Items.Clear();
                if (error != "null")
                {
                    dish_data[] objdata = JsonConvert.DeserializeObject<dish_data[]>(obj["data"].ToString());
                    foreach (dish_data myJsonObj in objdata)
                    {
                        dishes newDish = new dishes();
                        newDish.dname = myJsonObj.dname;
                        newDish.cap = myJsonObj.cap;
                        dishbox.Items.Add(myJsonObj.dname);
                        dish_list.Add(newDish);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private void dishesbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            volumebox.Show();
            volumebox.Items.Clear();
            for (int i = 0; i < dish_list.Count; i++)
                if (dish_list[i].dname == dishbox.Text)
                    volumebox.Items.Add(dish_list[i].cap);
        }
        private void delete_Click(object sender, EventArgs e)
        {
            if (check_data())
            {
                Response_to_server_delete();
                MessageBox.Show("Удалено!");
                this.Close();
            }
        }

        private void volumebox_SelectedIndexChanged(object sender, EventArgs e)
        {
            delete_b.Show();
        }
    }
}
