﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class add_price : Form
    {
        public add_price()
        {
            InitializeComponent();
            Response_to_server_get_dishes();
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct dish_data
        {
            [JsonProperty("dname")]
            public string dname { get; set; }
            [JsonProperty("cap")]
            public string cap { get; set; }
        }
        private class dishes
        {
            public string dname { get; set; }
            public string cap { get; set; }
            public string dish_cap { get; set; }
        }
        List<dishes> dish_list = new List<dishes>();
        private string error;
        private void Response_to_server_get_dishes()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                //запрос на сервер
                WebRequest request = WebRequest.Create(String.Format("https://localhost/search.php?search=dishes"));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                //получаем ответ от сервера
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                dish_list.Clear();
                namedish.Items.Clear();
                //если данные пришли (не null), то парсим наши данные в структуру и класс
                if (error != "null")
                {
                    dish_data[] objdata = JsonConvert.DeserializeObject<dish_data[]>(obj["data"].ToString());
                    foreach (dish_data myJsonObj in objdata)
                    {
                        dishes newDish = new dishes();
                        newDish.dname = myJsonObj.dname;
                        newDish.cap = myJsonObj.cap;
                        newDish.dish_cap = myJsonObj.dname + ", " + myJsonObj.cap;
                        namedish.Items.Add(myJsonObj.dname + ", " + myJsonObj.cap);
                        dish_list.Add(newDish);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }

        private bool Response_to_server_get_rest()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/search.php?search=rest&restname={0}",rest_tb.Text));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                if (error != "null")
                    return true;
                else
                {
                    MessageBox.Show("Такого ресторана не существует!");
                    rest_tb.Text = "";
                    rest_tb.Focus();
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
                return false;
            }
        }

        private int search_dish()
        {
            for (int i = 0; i < dish_list.Count; i++)
                if (dish_list[i].dish_cap == namedish.Text)
                    return i;
            return -1;
            
        }

        private void Response_to_server_insert()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                int position = search_dish();
                WebRequest request = WebRequest.Create(String.Format("https://localhost/add.php?add=price&restname={0}&dish_name={1}&volume={2}&price={3}&session_id={4}", rest_tb.Text,dish_list[position].dname, dish_list[position].cap,price_tb.Text.Trim(' '),enter.session_id));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                if (error != "exist") 
                {
                    MessageBox.Show("Успешно!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Такого ресторана не существует!");
                    rest_tb.Text = "";
                    rest_tb.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
       
        private void add_dishb_Click(object sender, EventArgs e)
        {
            if (rest_tb.Text.Trim(' ') != "" && price_tb.Text.Trim(' ') != "" && namedish.Text.Trim(' ') != "")
            {
                if (Response_to_server_get_rest())
                    Response_to_server_insert();
            }
            else
                MessageBox.Show("Заполните все поля!");
        }
    }
}
