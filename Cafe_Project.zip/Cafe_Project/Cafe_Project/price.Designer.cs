﻿namespace Cafe_Project
{
    partial class price
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(price));
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pricetb = new System.Windows.Forms.TextBox();
            this.restb = new System.Windows.Forms.TextBox();
            this.name_dishtb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.navigatorPrice = new System.Windows.Forms.BindingNavigator(this.components);
            this.firstitem = new System.Windows.Forms.ToolStripButton();
            this.previtem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.nextitem = new System.Windows.Forms.ToolStripButton();
            this.lastitem = new System.Windows.Forms.ToolStripButton();
            this.saveitem = new System.Windows.Forms.ToolStripButton();
            this.deleteitem = new System.Windows.Forms.ToolStripButton();
            this.label2 = new System.Windows.Forms.Label();
            this.volumetb = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.navigatorPrice)).BeginInit();
            this.navigatorPrice.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(26, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 23);
            this.label4.TabIndex = 39;
            this.label4.Text = "Цена:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(26, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 23);
            this.label3.TabIndex = 38;
            this.label3.Text = "Ресторан:";
            // 
            // pricetb
            // 
            this.pricetb.Location = new System.Drawing.Point(184, 187);
            this.pricetb.Multiline = true;
            this.pricetb.Name = "pricetb";
            this.pricetb.Size = new System.Drawing.Size(355, 32);
            this.pricetb.TabIndex = 1;
            // 
            // restb
            // 
            this.restb.Location = new System.Drawing.Point(184, 149);
            this.restb.Multiline = true;
            this.restb.Name = "restb";
            this.restb.ReadOnly = true;
            this.restb.Size = new System.Drawing.Size(355, 32);
            this.restb.TabIndex = 35;
            // 
            // name_dishtb
            // 
            this.name_dishtb.Location = new System.Drawing.Point(184, 73);
            this.name_dishtb.Multiline = true;
            this.name_dishtb.Name = "name_dishtb";
            this.name_dishtb.ReadOnly = true;
            this.name_dishtb.Size = new System.Drawing.Size(355, 32);
            this.name_dishtb.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(26, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 23);
            this.label1.TabIndex = 32;
            this.label1.Text = "Название блюда:";
            // 
            // navigatorPrice
            // 
            this.navigatorPrice.AddNewItem = null;
            this.navigatorPrice.BackColor = System.Drawing.Color.Transparent;
            this.navigatorPrice.CountItem = null;
            this.navigatorPrice.DeleteItem = null;
            this.navigatorPrice.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstitem,
            this.previtem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorSeparator1,
            this.nextitem,
            this.lastitem,
            this.saveitem,
            this.deleteitem});
            this.navigatorPrice.Location = new System.Drawing.Point(0, 0);
            this.navigatorPrice.MoveFirstItem = this.firstitem;
            this.navigatorPrice.MoveLastItem = this.lastitem;
            this.navigatorPrice.MoveNextItem = this.nextitem;
            this.navigatorPrice.MovePreviousItem = this.previtem;
            this.navigatorPrice.Name = "navigatorPrice";
            this.navigatorPrice.PositionItem = null;
            this.navigatorPrice.Size = new System.Drawing.Size(627, 25);
            this.navigatorPrice.TabIndex = 40;
            this.navigatorPrice.Text = "bindingNavigator1";
            // 
            // firstitem
            // 
            this.firstitem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.firstitem.Image = ((System.Drawing.Image)(resources.GetObject("firstitem.Image")));
            this.firstitem.Name = "firstitem";
            this.firstitem.RightToLeftAutoMirrorImage = true;
            this.firstitem.Size = new System.Drawing.Size(23, 22);
            this.firstitem.Text = "Переместить в начало";
            this.firstitem.Click += new System.EventHandler(this.firstitem_Click);
            // 
            // previtem
            // 
            this.previtem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.previtem.Image = ((System.Drawing.Image)(resources.GetObject("previtem.Image")));
            this.previtem.Name = "previtem";
            this.previtem.RightToLeftAutoMirrorImage = true;
            this.previtem.Size = new System.Drawing.Size(23, 22);
            this.previtem.Text = "Переместить назад";
            this.previtem.Click += new System.EventHandler(this.previtem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // nextitem
            // 
            this.nextitem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.nextitem.Image = ((System.Drawing.Image)(resources.GetObject("nextitem.Image")));
            this.nextitem.Name = "nextitem";
            this.nextitem.RightToLeftAutoMirrorImage = true;
            this.nextitem.Size = new System.Drawing.Size(23, 22);
            this.nextitem.Text = "Переместить вперед";
            this.nextitem.Click += new System.EventHandler(this.nextitem_Click);
            // 
            // lastitem
            // 
            this.lastitem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.lastitem.Image = ((System.Drawing.Image)(resources.GetObject("lastitem.Image")));
            this.lastitem.Name = "lastitem";
            this.lastitem.RightToLeftAutoMirrorImage = true;
            this.lastitem.Size = new System.Drawing.Size(23, 22);
            this.lastitem.Text = "Переместить в конец";
            this.lastitem.Click += new System.EventHandler(this.lastitem_Click);
            // 
            // saveitem
            // 
            this.saveitem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveitem.Image = ((System.Drawing.Image)(resources.GetObject("saveitem.Image")));
            this.saveitem.Name = "saveitem";
            this.saveitem.Size = new System.Drawing.Size(23, 22);
            this.saveitem.Text = "Сохранить";
            this.saveitem.Click += new System.EventHandler(this.saveitem_Click);
            // 
            // deleteitem
            // 
            this.deleteitem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.deleteitem.Image = ((System.Drawing.Image)(resources.GetObject("deleteitem.Image")));
            this.deleteitem.Name = "deleteitem";
            this.deleteitem.RightToLeftAutoMirrorImage = true;
            this.deleteitem.Size = new System.Drawing.Size(23, 22);
            this.deleteitem.Text = "Удалить";
            this.deleteitem.Click += new System.EventHandler(this.deleteitem_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(26, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 23);
            this.label2.TabIndex = 42;
            this.label2.Text = "Объем:";
            // 
            // volumetb
            // 
            this.volumetb.Location = new System.Drawing.Point(184, 111);
            this.volumetb.Multiline = true;
            this.volumetb.Name = "volumetb";
            this.volumetb.ReadOnly = true;
            this.volumetb.Size = new System.Drawing.Size(355, 32);
            this.volumetb.TabIndex = 41;
            // 
            // price
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(627, 273);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.volumetb);
            this.Controls.Add(this.navigatorPrice);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pricetb);
            this.Controls.Add(this.restb);
            this.Controls.Add(this.name_dishtb);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "price";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Цены";
            ((System.ComponentModel.ISupportInitialize)(this.navigatorPrice)).EndInit();
            this.navigatorPrice.ResumeLayout(false);
            this.navigatorPrice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox pricetb;
        private System.Windows.Forms.TextBox restb;
        private System.Windows.Forms.TextBox name_dishtb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingNavigator navigatorPrice;
        private System.Windows.Forms.ToolStripButton firstitem;
        private System.Windows.Forms.ToolStripButton previtem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton nextitem;
        private System.Windows.Forms.ToolStripButton lastitem;
        private System.Windows.Forms.ToolStripButton saveitem;
        private System.Windows.Forms.ToolStripButton deleteitem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox volumetb;
    }
}