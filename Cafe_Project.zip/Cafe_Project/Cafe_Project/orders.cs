﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class orders : Form
    {
        public orders()
        {
            InitializeComponent();
            Response_to_server();
        }

        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }

        [JsonObject(MemberSerialization.OptIn)]
        struct orders_data
        {
            [JsonProperty("order_id")]
            public string order_id { get; set; }
            [JsonProperty("restname")]
            public string restname { get; set; }
            [JsonProperty("summa")]
            public decimal summa { get; set; }
            [JsonProperty("user_summa")]
            public decimal user_summa { get; set; }
            [JsonProperty("date")]
            public DateTime date { get; set; }
        }
        private class order_data
        {
            public int number { get; set; }
            public string order_id { get; set; }
            public string restname { get; set; }
            public decimal summa { get; set; }
            public decimal user_summa { get; set; }
            public DateTime date { get; set; }
        }
        List<order_data> order_list = new List<order_data>();

        private string error;

        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/order.php?select=order_user&session_id={0}", enter.session_id));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                order_list.Clear();
                if (error != "null")
                {
                    orders_data[] objdata = JsonConvert.DeserializeObject<orders_data[]>(obj["data"].ToString());
                    int i = 1;
                    foreach (orders_data myJsonObj in objdata)
                    {
                        order_data newOrder = new order_data();
                        newOrder.number = i;
                        newOrder.order_id = myJsonObj.order_id;
                        newOrder.restname = myJsonObj.restname;
                        newOrder.summa = myJsonObj.summa;
                        newOrder.user_summa = myJsonObj.user_summa;
                        newOrder.date = myJsonObj.date;
                        order_list.Add(newOrder);
                        i++;
                    }
                    summ_tb.Text = Convert.ToString(order_list[0].user_summa);
                    tableOrder.DataSource = order_list;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }

        private void contentb_Click(object sender, EventArgs e)
        {
            int j = tableOrder.CurrentRow.Index;
            order_content.order_id = order_list[(int)tableOrder["number_order", j].Value - 1].order_id;
            order_content oc = new order_content();
            oc.Show();
        }

        private void delete_ordb_Click(object sender, EventArgs e)
        {

        }
    }
}
