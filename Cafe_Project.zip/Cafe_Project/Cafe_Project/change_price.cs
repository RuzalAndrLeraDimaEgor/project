﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class change_price : Form
    {
        public change_price()
        {
            InitializeComponent();
        }

        private void adddishb_Click(object sender, EventArgs e)
        {
            add_dish adf = new add_dish();
            adf.ShowDialog();
        }

        private void chnageb_Click(object sender, EventArgs e)
        {
            price pf = new price("all");
            pf.ShowDialog();
        }

        private void addprice_Click(object sender, EventArgs e)
        {
            add_price apf = new add_price();
            apf.ShowDialog();
        }

        private void delete_dish_Click(object sender, EventArgs e)
        {
            delete_dishes ddf = new delete_dishes();
            ddf.ShowDialog();
        }
    }
}
