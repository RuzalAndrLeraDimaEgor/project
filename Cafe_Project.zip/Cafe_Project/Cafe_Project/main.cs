﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;


namespace Cafe_Project
{
    public partial class main : Form
    {
        public static bool flag ;
        public main()
        {
            InitializeComponent();
        }

        private void menub_Click(object sender, EventArgs e)
        {
            menu mf = new menu();
            mf.ShowDialog();
        }

        private void addressesb_Click(object sender, EventArgs e)
        {
            address_rest arf = new address_rest();
            arf.ShowDialog();
        }
        public bool flag1 = false;
        private void pcb_Click(object sender, EventArgs e)
        {
            if (flag)
            {
                flag1 = true;
                this.Close();
                flag1 = true;
                pc pcf = new pc();
                pcf.ShowDialog();
                
            }
            else
            {
                flag1 = true;
                this.Close();
                flag1 = true;
                enter ef = new enter();
                ef.ShowDialog(); 
            }
        }
        
        private void enter_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!flag1)
             Application.Exit();
        }
    }
}
