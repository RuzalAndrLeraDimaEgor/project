﻿namespace Cafe_Project
{
    partial class address_rest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(address_rest));
            this.tableAddress = new System.Windows.Forms.DataGridView();
            this.name_cafe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tableAddress)).BeginInit();
            this.SuspendLayout();
            // 
            // tableAddress
            // 
            this.tableAddress.AllowUserToAddRows = false;
            this.tableAddress.AllowUserToDeleteRows = false;
            this.tableAddress.BackgroundColor = System.Drawing.Color.LemonChiffon;
            this.tableAddress.ColumnHeadersHeight = 30;
            this.tableAddress.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name_cafe,
            this.address});
            this.tableAddress.GridColor = System.Drawing.Color.LightSteelBlue;
            this.tableAddress.Location = new System.Drawing.Point(67, 120);
            this.tableAddress.Margin = new System.Windows.Forms.Padding(4);
            this.tableAddress.Name = "tableAddress";
            this.tableAddress.Size = new System.Drawing.Size(795, 386);
            this.tableAddress.TabIndex = 0;
            // 
            // name_cafe
            // 
            this.name_cafe.DataPropertyName = "restname";
            this.name_cafe.HeaderText = "Название";
            this.name_cafe.Name = "name_cafe";
            this.name_cafe.ReadOnly = true;
            this.name_cafe.Width = 200;
            // 
            // address
            // 
            this.address.DataPropertyName = "address";
            this.address.HeaderText = "Адрес";
            this.address.Name = "address";
            this.address.ReadOnly = true;
            this.address.Width = 550;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.Location = new System.Drawing.Point(220, 53);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(506, 45);
            this.label1.TabIndex = 4;
            this.label1.Text = "Адреса    ресторанов     Andiamo ";
            // 
            // address_rest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.ClientSize = new System.Drawing.Size(941, 583);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tableAddress);
            this.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "address_rest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Адреса";
            ((System.ComponentModel.ISupportInitialize)(this.tableAddress)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView tableAddress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn name_cafe;
        private System.Windows.Forms.DataGridViewTextBoxColumn address;
    }
}