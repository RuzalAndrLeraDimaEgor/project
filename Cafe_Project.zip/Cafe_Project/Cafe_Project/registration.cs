﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class registration : Form
    {
        public registration()
        {
            InitializeComponent();
        }

        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }
        private string error;
        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/registration.php?email={0}&password={1}&phone={2}&address={3}&fio={4}", emailtb.Text.Trim(' '), passtb.Text.Trim(' '), phonetb.Text, addresstb.Text, nametb.Text));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private bool check_data()
        {
            if (emailtb.Text.Trim(' ') == "" || passtb.Text.Trim(' ') == "")
            {
                MessageBox.Show("Введите данные!");
                emailtb.Focus();
                return false;
            }
            return true;
        }
        private void reg_b_Click(object sender, EventArgs e)
        {
            if (check_data())
            {
                Response_to_server();
                if (error == "error")
                {
                    MessageBox.Show("Такой пользователь уже существует!");
                    emailtb.Text = "";
                    passtb.Text = "";
                    return;
                }
                else
                {
                    MessageBox.Show("Вы зарегистрированы!");
                    this.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
 
    }
}
