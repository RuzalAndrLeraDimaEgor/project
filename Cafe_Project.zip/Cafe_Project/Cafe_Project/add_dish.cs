﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;


namespace Cafe_Project
{
    public partial class add_dish : Form
    {
        public add_dish()
        {
            InitializeComponent();
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }
        private string error;
        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                //запрос на сервер
                WebRequest request = WebRequest.Create(String.Format("https://localhost/add.php?add=dish&dish_name={0}&volume={1}&name={2}&price={3}&session_id={4}", name_dish.Text, volume_tb.Text.Trim(' '), rest_tb.Text, price_tb.Text.Trim(' '), enter.session_id));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                //получаем ответ от сервера
                var responseFromServer = reader.ReadToEnd();
                //парсим полученный массив
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                //получаем тип ошибки
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private bool check_data()
        {
            if (name_dish.Text.Trim(' ') == "" || volume_tb.Text.Trim(' ') == "" || rest_tb.Text == "" || price_tb.Text=="")
            {
                MessageBox.Show("Введите данные!");
                return false;
            }
            return true;
        }
        private void add_dishb_Click(object sender, EventArgs e)
        {
            if (check_data())
            {
                Response_to_server();
                if (error == "notcafe")
                {
                    MessageBox.Show("Такого ресторана нет в базе данных");
                    rest_tb.Text = "";
                    rest_tb.Focus();
                    return;
                }
                if (error == "exist_dish")
                {
                    MessageBox.Show("Такое блюдо уже существует!");
                    name_dish.Text = "";
                    name_dish.Focus();
                    return;
                }
                MessageBox.Show("Успешно добавлено!");
                this.Close();
            }

        }
    }
}
