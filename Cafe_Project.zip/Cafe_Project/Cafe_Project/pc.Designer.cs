﻿namespace Cafe_Project
{
    partial class pc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pc));
            this.label1 = new System.Windows.Forms.Label();
            this.change_datab = new System.Windows.Forms.Button();
            this.orderb = new System.Windows.Forms.Button();
            this.ordersb = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statb = new System.Windows.Forms.Button();
            this.allordersb = new System.Windows.Forms.Button();
            this.change_priceb = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.go_to_mainlink = new System.Windows.Forms.LinkLabel();
            this.exit = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.Location = new System.Drawing.Point(21, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 33);
            this.label1.TabIndex = 5;
            this.label1.Text = "Личный кабинет";
            // 
            // change_datab
            // 
            this.change_datab.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.change_datab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.change_datab.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.change_datab.FlatAppearance.BorderSize = 2;
            this.change_datab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.change_datab.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.change_datab.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.change_datab.Location = new System.Drawing.Point(59, 123);
            this.change_datab.Name = "change_datab";
            this.change_datab.Size = new System.Drawing.Size(195, 41);
            this.change_datab.TabIndex = 30;
            this.change_datab.Text = "Изменить данные";
            this.change_datab.UseVisualStyleBackColor = true;
            this.change_datab.Click += new System.EventHandler(this.change_datab_Click);
            // 
            // orderb
            // 
            this.orderb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.orderb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.orderb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.orderb.FlatAppearance.BorderSize = 2;
            this.orderb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.orderb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orderb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.orderb.Location = new System.Drawing.Point(59, 181);
            this.orderb.Name = "orderb";
            this.orderb.Size = new System.Drawing.Size(195, 41);
            this.orderb.TabIndex = 31;
            this.orderb.Text = "Сделать заказ";
            this.orderb.UseVisualStyleBackColor = true;
            this.orderb.Click += new System.EventHandler(this.orderb_Click);
            // 
            // ordersb
            // 
            this.ordersb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.ordersb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ordersb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.ordersb.FlatAppearance.BorderSize = 2;
            this.ordersb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ordersb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ordersb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ordersb.Location = new System.Drawing.Point(59, 241);
            this.ordersb.Name = "ordersb";
            this.ordersb.Size = new System.Drawing.Size(195, 41);
            this.ordersb.TabIndex = 32;
            this.ordersb.Text = "Мои заказы";
            this.ordersb.UseVisualStyleBackColor = true;
            this.ordersb.Click += new System.EventHandler(this.ordersb_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::Cafe_Project.Properties.Resources.fon;
            this.pictureBox1.Location = new System.Drawing.Point(27, 103);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(256, 214);
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // statb
            // 
            this.statb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.statb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.statb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.statb.FlatAppearance.BorderSize = 2;
            this.statb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.statb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.statb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.statb.Location = new System.Drawing.Point(409, 241);
            this.statb.Name = "statb";
            this.statb.Size = new System.Drawing.Size(195, 41);
            this.statb.TabIndex = 36;
            this.statb.Text = "Статистика";
            this.statb.UseVisualStyleBackColor = true;
            this.statb.Click += new System.EventHandler(this.statb_Click);
            // 
            // allordersb
            // 
            this.allordersb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.allordersb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.allordersb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.allordersb.FlatAppearance.BorderSize = 2;
            this.allordersb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.allordersb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.allordersb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.allordersb.Location = new System.Drawing.Point(409, 181);
            this.allordersb.Name = "allordersb";
            this.allordersb.Size = new System.Drawing.Size(195, 41);
            this.allordersb.TabIndex = 35;
            this.allordersb.Text = "Все заказы";
            this.allordersb.UseVisualStyleBackColor = true;
            this.allordersb.Click += new System.EventHandler(this.allordersb_Click);
            // 
            // change_priceb
            // 
            this.change_priceb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.change_priceb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.change_priceb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.change_priceb.FlatAppearance.BorderSize = 2;
            this.change_priceb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.change_priceb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.change_priceb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.change_priceb.Location = new System.Drawing.Point(409, 123);
            this.change_priceb.Name = "change_priceb";
            this.change_priceb.Size = new System.Drawing.Size(195, 41);
            this.change_priceb.TabIndex = 34;
            this.change_priceb.Text = "Изменить прайс";
            this.change_priceb.UseVisualStyleBackColor = true;
            this.change_priceb.Click += new System.EventHandler(this.change_priceb_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::Cafe_Project.Properties.Resources.fon;
            this.pictureBox2.Location = new System.Drawing.Point(377, 103);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(256, 214);
            this.pictureBox2.TabIndex = 37;
            this.pictureBox2.TabStop = false;
            // 
            // go_to_mainlink
            // 
            this.go_to_mainlink.ActiveLinkColor = System.Drawing.Color.Black;
            this.go_to_mainlink.AutoSize = true;
            this.go_to_mainlink.BackColor = System.Drawing.Color.Transparent;
            this.go_to_mainlink.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.go_to_mainlink.ForeColor = System.Drawing.Color.Transparent;
            this.go_to_mainlink.LinkColor = System.Drawing.Color.White;
            this.go_to_mainlink.Location = new System.Drawing.Point(24, 73);
            this.go_to_mainlink.Name = "go_to_mainlink";
            this.go_to_mainlink.Size = new System.Drawing.Size(166, 19);
            this.go_to_mainlink.TabIndex = 38;
            this.go_to_mainlink.TabStop = true;
            this.go_to_mainlink.Text = "Вернуться на главную";
            this.go_to_mainlink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.go_to_mainlink_LinkClicked);
            // 
            // exit
            // 
            this.exit.ActiveLinkColor = System.Drawing.Color.Black;
            this.exit.AutoSize = true;
            this.exit.BackColor = System.Drawing.Color.Transparent;
            this.exit.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exit.ForeColor = System.Drawing.Color.Transparent;
            this.exit.LinkColor = System.Drawing.Color.White;
            this.exit.Location = new System.Drawing.Point(23, 333);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(132, 19);
            this.exit.TabIndex = 39;
            this.exit.TabStop = true;
            this.exit.Text = "Выйти с аккаунта";
            this.exit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.exit_LinkClicked);
            // 
            // pc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(672, 384);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.go_to_mainlink);
            this.Controls.Add(this.statb);
            this.Controls.Add(this.allordersb);
            this.Controls.Add(this.change_priceb);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.ordersb);
            this.Controls.Add(this.orderb);
            this.Controls.Add(this.change_datab);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "pc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Личный кабинет";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.enter_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button change_datab;
        private System.Windows.Forms.Button orderb;
        private System.Windows.Forms.Button ordersb;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button statb;
        private System.Windows.Forms.Button allordersb;
        private System.Windows.Forms.Button change_priceb;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.LinkLabel go_to_mainlink;
        private System.Windows.Forms.LinkLabel exit;
    }
}