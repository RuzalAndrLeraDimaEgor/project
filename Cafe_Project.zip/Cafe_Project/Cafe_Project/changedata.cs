﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class changedata : Form
    {
        public changedata()
        {
            InitializeComponent();
            Response_to_server();
        }
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct user_data
        {
            [JsonProperty("fio")]
            public string fio { get; set; }
            [JsonProperty("address")]
            public string address { get; set; }
            [JsonProperty("phone")]
            public string phone { get; set; }
            [JsonProperty("card")]
            public string card { get; set; }
            [JsonProperty("info")]
            public string info { get; set; }
        }


        private string error;
        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/search.php?search=info&session_id={0}", enter.session_id));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                if (error != "null")
                {
                    user_data[] objdata = JsonConvert.DeserializeObject<user_data[]>(obj["data"].ToString());
                    foreach (user_data myJsonObj in objdata)
                    {
                        nametb.Text= myJsonObj.fio;
                        addresstb.Text = myJsonObj.address;
                        phonetb.Text = myJsonObj.phone;
                        cardtb.Text = myJsonObj.card;
                        abouttb.Text = myJsonObj.info;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }

        private void Response_to_server_update()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/update.php?update=data&session_id={0}&fio={1}&address={2}&phone={3}&card={4}&about={5}", enter.session_id,nametb.Text,addresstb.Text,phonetb.Text,cardtb.Text,abouttb.Text));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private void save_infob_Click(object sender, EventArgs e)
        {
            Response_to_server_update();
            MessageBox.Show("Успешно!");
            this.Close();
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
