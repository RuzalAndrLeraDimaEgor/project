﻿namespace Cafe_Project
{
    partial class search_dish
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(search_dish));
            this.search_nametb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.navigatorPrice = new System.Windows.Forms.BindingNavigator(this.components);
            this.firstitem = new System.Windows.Forms.ToolStripButton();
            this.previtem = new System.Windows.Forms.ToolStripButton();
            this.nextitem = new System.Windows.Forms.ToolStripButton();
            this.lastitem = new System.Windows.Forms.ToolStripButton();
            this.searchb = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.addresstb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pricetb = new System.Windows.Forms.TextBox();
            this.resttb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dish_nametb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.volumetb = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.navigatorPrice)).BeginInit();
            this.navigatorPrice.SuspendLayout();
            this.SuspendLayout();
            // 
            // search_nametb
            // 
            this.search_nametb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.search_nametb.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.search_nametb.Location = new System.Drawing.Point(41, 87);
            this.search_nametb.Multiline = true;
            this.search_nametb.Name = "search_nametb";
            this.search_nametb.Size = new System.Drawing.Size(288, 41);
            this.search_nametb.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(36, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 26);
            this.label1.TabIndex = 9;
            this.label1.Text = "Название блюда:";
            // 
            // navigatorPrice
            // 
            this.navigatorPrice.AddNewItem = null;
            this.navigatorPrice.BackColor = System.Drawing.Color.Transparent;
            this.navigatorPrice.CountItem = null;
            this.navigatorPrice.DeleteItem = null;
            this.navigatorPrice.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstitem,
            this.previtem,
            this.nextitem,
            this.lastitem});
            this.navigatorPrice.Location = new System.Drawing.Point(0, 0);
            this.navigatorPrice.MoveFirstItem = this.firstitem;
            this.navigatorPrice.MoveLastItem = this.lastitem;
            this.navigatorPrice.MoveNextItem = this.nextitem;
            this.navigatorPrice.MovePreviousItem = this.previtem;
            this.navigatorPrice.Name = "navigatorPrice";
            this.navigatorPrice.PositionItem = null;
            this.navigatorPrice.Size = new System.Drawing.Size(543, 25);
            this.navigatorPrice.TabIndex = 11;
            this.navigatorPrice.Text = "bindingNavigator1";
            // 
            // firstitem
            // 
            this.firstitem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.firstitem.Image = ((System.Drawing.Image)(resources.GetObject("firstitem.Image")));
            this.firstitem.Name = "firstitem";
            this.firstitem.RightToLeftAutoMirrorImage = true;
            this.firstitem.Size = new System.Drawing.Size(23, 22);
            this.firstitem.Text = "Переместить в начало";
            this.firstitem.Click += new System.EventHandler(this.firstitem_Click);
            // 
            // previtem
            // 
            this.previtem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.previtem.Image = ((System.Drawing.Image)(resources.GetObject("previtem.Image")));
            this.previtem.Name = "previtem";
            this.previtem.RightToLeftAutoMirrorImage = true;
            this.previtem.Size = new System.Drawing.Size(23, 22);
            this.previtem.Text = "Переместить назад";
            this.previtem.Click += new System.EventHandler(this.previtem_Click);
            // 
            // nextitem
            // 
            this.nextitem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.nextitem.Image = ((System.Drawing.Image)(resources.GetObject("nextitem.Image")));
            this.nextitem.Name = "nextitem";
            this.nextitem.RightToLeftAutoMirrorImage = true;
            this.nextitem.Size = new System.Drawing.Size(23, 22);
            this.nextitem.Text = "Переместить вперед";
            this.nextitem.Click += new System.EventHandler(this.nextitem_Click);
            // 
            // lastitem
            // 
            this.lastitem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.lastitem.Image = ((System.Drawing.Image)(resources.GetObject("lastitem.Image")));
            this.lastitem.Name = "lastitem";
            this.lastitem.RightToLeftAutoMirrorImage = true;
            this.lastitem.Size = new System.Drawing.Size(23, 22);
            this.lastitem.Text = "Переместить в конец";
            this.lastitem.Click += new System.EventHandler(this.lastitem_Click);
            // 
            // searchb
            // 
            this.searchb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.searchb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.searchb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.searchb.FlatAppearance.BorderSize = 2;
            this.searchb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.searchb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.searchb.Location = new System.Drawing.Point(349, 87);
            this.searchb.Name = "searchb";
            this.searchb.Size = new System.Drawing.Size(155, 41);
            this.searchb.TabIndex = 29;
            this.searchb.Text = "Поиск блюда";
            this.searchb.UseVisualStyleBackColor = true;
            this.searchb.Click += new System.EventHandler(this.searchb_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(36, 387);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 26);
            this.label3.TabIndex = 36;
            this.label3.Text = "Адрес:";
            // 
            // addresstb
            // 
            this.addresstb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.addresstb.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addresstb.Location = new System.Drawing.Point(41, 416);
            this.addresstb.Multiline = true;
            this.addresstb.Name = "addresstb";
            this.addresstb.Size = new System.Drawing.Size(463, 41);
            this.addresstb.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(36, 460);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 26);
            this.label2.TabIndex = 34;
            this.label2.Text = "Цена:";
            // 
            // pricetb
            // 
            this.pricetb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pricetb.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pricetb.Location = new System.Drawing.Point(41, 489);
            this.pricetb.Multiline = true;
            this.pricetb.Name = "pricetb";
            this.pricetb.Size = new System.Drawing.Size(463, 41);
            this.pricetb.TabIndex = 5;
            // 
            // resttb
            // 
            this.resttb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.resttb.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.resttb.Location = new System.Drawing.Point(41, 343);
            this.resttb.Multiline = true;
            this.resttb.Name = "resttb";
            this.resttb.Size = new System.Drawing.Size(463, 41);
            this.resttb.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(36, 314);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 26);
            this.label4.TabIndex = 31;
            this.label4.Text = "Ресторан:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(36, 168);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 26);
            this.label5.TabIndex = 37;
            this.label5.Text = "Блюдо:";
            // 
            // dish_nametb
            // 
            this.dish_nametb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.dish_nametb.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dish_nametb.Location = new System.Drawing.Point(41, 197);
            this.dish_nametb.Multiline = true;
            this.dish_nametb.Name = "dish_nametb";
            this.dish_nametb.Size = new System.Drawing.Size(463, 41);
            this.dish_nametb.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(36, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 26);
            this.label6.TabIndex = 39;
            this.label6.Text = "Объем:";
            // 
            // volumetb
            // 
            this.volumetb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.volumetb.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.volumetb.Location = new System.Drawing.Point(41, 270);
            this.volumetb.Multiline = true;
            this.volumetb.Name = "volumetb";
            this.volumetb.Size = new System.Drawing.Size(463, 41);
            this.volumetb.TabIndex = 2;
            // 
            // search_dish
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.ClientSize = new System.Drawing.Size(543, 555);
            this.Controls.Add(this.volumetb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dish_nametb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.addresstb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pricetb);
            this.Controls.Add(this.resttb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.searchb);
            this.Controls.Add(this.navigatorPrice);
            this.Controls.Add(this.search_nametb);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "search_dish";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Поиск блюда";
            ((System.ComponentModel.ISupportInitialize)(this.navigatorPrice)).EndInit();
            this.navigatorPrice.ResumeLayout(false);
            this.navigatorPrice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox search_nametb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingNavigator navigatorPrice;
        private System.Windows.Forms.ToolStripButton firstitem;
        private System.Windows.Forms.ToolStripButton previtem;
        private System.Windows.Forms.ToolStripButton nextitem;
        private System.Windows.Forms.ToolStripButton lastitem;
        private System.Windows.Forms.Button searchb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox addresstb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox pricetb;
        private System.Windows.Forms.TextBox resttb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox dish_nametb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox volumetb;
    }
}