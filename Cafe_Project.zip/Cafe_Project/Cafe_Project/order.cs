﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class order : Form
    {
        public static string rest_name;
        public static bool flag_order;
        public static string order_id;
        public order()
        {
            InitializeComponent();
            Response_to_server_get_rest();
            priceb.Visible = false;
            take_ord.Visible = false;
        }

        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct price_all
        {
            [JsonProperty("price")]
            public decimal price_ { get; set; }
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct orderid
        {
            [JsonProperty("uuid()")]
            public string orderi { get; set; }
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct dish_data
        {
            [JsonProperty("cap")]
            public string cap { get; set; }
            [JsonProperty("dname")]
            public string dname { get; set; }
            [JsonProperty("restname")]
            public string restname { get; set; }
        }
        struct rest_data
        {
            [JsonProperty("restname")]
            public string restname { get; set; }
        }
        private class data_dish
        {
            public string cap{ get; set; }
            public string restname { get; set; }
            public string dname { get; set; }
        }
        List<data_dish> data_dishes = new List<data_dish>();

        private string error;

        private void Response_to_server_get_rest()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create("https://localhost/search.php?search=all_dish");
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                if (!flag_order)
                {
                    WebRequest req1 = WebRequest.Create("https://localhost/search.php?search=all_rest");
                    req1.Proxy = null;
                    req1.Credentials = CredentialCache.DefaultCredentials;
                    HttpWebResponse response1 = (HttpWebResponse)req1.GetResponse();
                    Stream dataStream1 = response1.GetResponseStream();
                    StreamReader reader1 = new StreamReader(dataStream1);
                    var responseFromServer1 = reader1.ReadToEnd();
                    Newtonsoft.Json.Linq.JObject obj1 = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer1);
                    type_error[] objArr1 = JsonConvert.DeserializeObject<type_error[]>(obj1["type"].ToString());
                    foreach (type_error myJsonObj in objArr1)
                        error = myJsonObj.error;
                    if (error != "error")
                    {
                        rest_data[] objdata1 = JsonConvert.DeserializeObject<rest_data[]>(obj1["data"].ToString());
                        restbox.Items.Clear();
                        foreach (rest_data myJsonObj in objdata1)
                            if (!flag_order)
                                restbox.Items.Add(myJsonObj.restname);
                    }
                }
                else
                    restbox.Items.Add(rest_name);
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                data_dishes.Clear();
                if (error != "error")
                {
                    dish_data[] objdata = JsonConvert.DeserializeObject<dish_data[]>(obj["data"].ToString());
                    volumebox.Items.Clear();
                    dishesbox.Items.Clear();
                    foreach (dish_data myJsonObj in objdata)
                    {
                        data_dish newOrder = new data_dish();
                        newOrder.restname = myJsonObj.restname;
                        newOrder.cap = myJsonObj.cap;
                        newOrder.dname = myJsonObj.dname;
                        data_dishes.Add(newOrder);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private void Response_to_server_get_price()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/order.php?select=get_price&restname={0}&dish_name={1}&volume={2}&session_id={3}",restbox.Text,dishesbox.Text,volumebox.Text.Trim(' '),enter.session_id));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                //Console.WriteLine("\n" + responseFromServer + "\n");

                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                if (error != "error")
                {
                    price_all[] objdata = JsonConvert.DeserializeObject<price_all[]>(obj["data"].ToString());
                    foreach (price_all myJsonObj in objdata)
                        pricetb.Text = Convert.ToString(Convert.ToInt32(counttb.Text) * myJsonObj.price_);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private void Response_to_server_make_order()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                string query;
                if (flag_order)
                    query = String.Format("https://localhost/order.php?select=make_order&restname={0}&dish_name={1}&volume={2}&count={3}&session_id={4}&flag={5}&order_id={6}", restbox.Text, dishesbox.Text, volumebox.Text, counttb.Text.Trim(' '), enter.session_id, "with", order_id);
                else
                    query = String.Format("https://localhost/order.php?select=make_order&restname={0}&dish_name={1}&volume={2}&count={3}&card={4}&session_id={5}&flag={6}", restbox.Text, dishesbox.Text, volumebox.Text,Convert.ToInt32(counttb.Text.Trim(' ')), numcard.Text, enter.session_id,"without");

                WebRequest request = WebRequest.Create(query);
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                //Console.WriteLine("\n" + responseFromServer + "\n");
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                if (error != "error")
                {
                    if (!flag_order)
                    {
                        orderid[] objdata = JsonConvert.DeserializeObject<orderid[]>(obj["data"].ToString());
                        foreach (orderid myJsonObj in objdata)
                            order_id = myJsonObj.orderi;
                        flag_order = true;
                        rest_name = restbox.Text;
                        restbox.Items.Clear();
                        restbox.Items.Add(rest_name);
                    }
                    MessageBox.Show("Успешно!");
                    clear_box();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }
        private void chooseb_Click(object sender, EventArgs e)
        {
            counttb.Text = "";
            pricetb.Text = "";
            if (restbox.Text != "")
            {
                dishesbox.Items.Clear();
                volumebox.Items.Clear();
                for (int i = 0; i < data_dishes.Count; i++)
                    if (restbox.Text==data_dishes[i].restname)
                        dishesbox.Items.Add(data_dishes[i].dname);
                priceb.Visible = true;
                priceb.Enabled = true;
                priceb.Text = "Рассчитать цену";
            }
        }

        private void clear_box()
        {
            dishesbox.Items.Clear();
            volumebox.Items.Clear();
            dishesbox.Text = "";
            volumebox.Text = "";
            counttb.Text = "";
            priceb.Text = "";
            priceb.Visible = false;
            pricetb.Text = "";
            take_ord.Visible = false;
            if (flag_order)
            {
                numcard.Visible = false;
                label2.Visible = false;
            }
            
        }
        private bool check_box()
        {
            if (dishesbox.Text == "" || volumebox.Text.Trim(' ') == "" || restbox.Text == "")
            {
                MessageBox.Show("Выберите данные!");
                return false;
            }
            if (counttb.Text.Trim(' ') == "" )
            {
                MessageBox.Show("Введите количество!");
                return false;
            }
            
            return true;
        }
        private void priceb_Click(object sender, EventArgs e)
        {
            if (check_box())
            {
                Response_to_server_get_price();
                take_ord.Visible = true;
            }
        }

        private void take_ord_Click(object sender, EventArgs e)
        {
            if (check_box())
            {
                if (numcard.Text.Trim(' ') == "" && !flag_order)
                {
                    MessageBox.Show("Введите номер карты!");
                    return;
                }
                Response_to_server_make_order();
            }
            
        }

        private void dishesbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            volumebox.Items.Clear();
            for (int i = 0; i < data_dishes.Count; i++)
                if (data_dishes[i].dname == dishesbox.Text && data_dishes[i].restname == restbox.Text)
                    volumebox.Items.Add(data_dishes[i].cap);
        }

    }
}
