﻿namespace Cafe_Project
{
    partial class change_price
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(change_price));
            this.adddishb = new System.Windows.Forms.Button();
            this.changeb = new System.Windows.Forms.Button();
            this.add_price_b = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.delete_dish = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // adddishb
            // 
            this.adddishb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.adddishb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.adddishb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.adddishb.FlatAppearance.BorderSize = 2;
            this.adddishb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adddishb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.adddishb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.adddishb.Location = new System.Drawing.Point(73, 109);
            this.adddishb.Name = "adddishb";
            this.adddishb.Size = new System.Drawing.Size(193, 41);
            this.adddishb.TabIndex = 1;
            this.adddishb.Text = "Добавить блюдо";
            this.adddishb.UseVisualStyleBackColor = true;
            this.adddishb.Click += new System.EventHandler(this.adddishb_Click);
            // 
            // changeb
            // 
            this.changeb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.changeb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.changeb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.changeb.FlatAppearance.BorderSize = 2;
            this.changeb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.changeb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.changeb.Location = new System.Drawing.Point(73, 156);
            this.changeb.Name = "changeb";
            this.changeb.Size = new System.Drawing.Size(193, 41);
            this.changeb.TabIndex = 2;
            this.changeb.Text = "Изменить цены";
            this.changeb.UseVisualStyleBackColor = true;
            this.changeb.Click += new System.EventHandler(this.chnageb_Click);
            // 
            // add_price_b
            // 
            this.add_price_b.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.add_price_b.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add_price_b.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.add_price_b.FlatAppearance.BorderSize = 2;
            this.add_price_b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_price_b.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.add_price_b.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.add_price_b.Location = new System.Drawing.Point(73, 203);
            this.add_price_b.Name = "add_price_b";
            this.add_price_b.Size = new System.Drawing.Size(193, 41);
            this.add_price_b.TabIndex = 3;
            this.add_price_b.Text = "Добавить в прайс";
            this.add_price_b.UseVisualStyleBackColor = true;
            this.add_price_b.Click += new System.EventHandler(this.addprice_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.Info;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label4.Location = new System.Drawing.Point(57, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(212, 33);
            this.label4.TabIndex = 32;
            this.label4.Text = "Изменение прайса";
            // 
            // delete_dish
            // 
            this.delete_dish.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.delete_dish.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.delete_dish.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.delete_dish.FlatAppearance.BorderSize = 2;
            this.delete_dish.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delete_dish.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delete_dish.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.delete_dish.Location = new System.Drawing.Point(76, 250);
            this.delete_dish.Name = "delete_dish";
            this.delete_dish.Size = new System.Drawing.Size(193, 41);
            this.delete_dish.TabIndex = 33;
            this.delete_dish.Text = "Удалить блюдо";
            this.delete_dish.UseVisualStyleBackColor = true;
            this.delete_dish.Click += new System.EventHandler(this.delete_dish_Click);
            // 
            // change_price
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(330, 350);
            this.Controls.Add(this.delete_dish);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.add_price_b);
            this.Controls.Add(this.changeb);
            this.Controls.Add(this.adddishb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "change_price";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Изменить прайс";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button adddishb;
        private System.Windows.Forms.Button changeb;
        private System.Windows.Forms.Button add_price_b;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button delete_dish;
    }
}