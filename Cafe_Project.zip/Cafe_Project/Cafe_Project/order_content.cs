﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class order_content : Form
    {
        public static string order_id;
        public order_content()
        {
            InitializeComponent();
            Response_to_server();
        }

        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }

        [JsonObject(MemberSerialization.OptIn)]
        struct orders_data
        {
            [JsonProperty("dname")]
            public string dname { get; set; }
            [JsonProperty("count")]
            public int count { get; set; }
            [JsonProperty("price")]
            public decimal price { get; set; }
        }
        private class order_data
        {
            public string dname { get; set; }
            public int count { get; set; }
            public decimal price { get; set; }
        }
        List<order_data> order_list = new List<order_data>();

        private string error;

        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/order.php?select=order_content&session_id={0}&order_id={1}", enter.session_id,order_id));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                order_list.Clear();
                if (error != "null")
                {
                    orders_data[] objdata = JsonConvert.DeserializeObject<orders_data[]>(obj["data"].ToString());
                    foreach (orders_data myJsonObj in objdata)
                    {
                        order_data newOrder = new order_data();
                        newOrder.dname = myJsonObj.dname;
                        newOrder.price = myJsonObj.price;
                        newOrder.count = myJsonObj.count;
                        order_list.Add(newOrder);
                    }
                    tableOrder.DataSource = order_list;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }

    }
}
