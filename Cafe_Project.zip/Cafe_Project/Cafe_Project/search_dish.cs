﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class search_dish : Form
    {
        private int position;
        public search_dish()
        {
            position = 0;
            InitializeComponent();
            previtem.Visible = false;
            nextitem.Visible = false;
            lastitem.Visible = false;
            firstitem.Visible = false;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct type_error
        {
            [JsonProperty("error")]
            public string error { get; set; }
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        [JsonObject(MemberSerialization.OptIn)]
        struct data_dish
        {
            [JsonProperty("dname")]
            public string dname { get; set; }
            [JsonProperty("address")]
            public string address { get; set; }
            [JsonProperty("price")]
            public decimal price { get; set; }
            [JsonProperty("cap")]
            public decimal cap { get; set; }
            [JsonProperty("restname")]
            public string restname { get; set; }
        }

        private class dishes
        {
            public string dname { get; set; }
            public string address { get; set; }
            public decimal cap { get; set; }
            public decimal price { get; set; }
            public string restname { get; set; }
        }

        List<dishes> dish_list = new List<dishes>();
        private void refresh()
        {
            if (dish_list.Count - 1 < 1)
            {
                previtem.Visible = false;
                firstitem.Visible = false;
                nextitem.Visible = false;
                lastitem.Visible = false;
            }
            else
            {
                if (position - 1 < 0)
                {
                    previtem.Visible = false;
                    firstitem.Visible = false;
                    nextitem.Visible = true;
                    nextitem.Enabled = true;
                    lastitem.Visible = true;
                    lastitem.Enabled = true;
                    return;
                }
                if (position == dish_list.Count - 1)
                {
                    previtem.Visible = true;
                    firstitem.Visible = true;
                    previtem.Enabled = true;
                    firstitem.Enabled = true;
                    nextitem.Visible = false;
                    lastitem.Visible = false;
                }
                else
                {
                    previtem.Visible = true;
                    firstitem.Visible = true;
                    previtem.Enabled = true;
                    firstitem.Enabled = true;
                    nextitem.Enabled = true;
                    lastitem.Enabled = true;
                    nextitem.Visible = true;
                    lastitem.Visible = true;
                }
            }
        }


        private string error;
        private void Response_to_server()
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                WebRequest request = WebRequest.Create(String.Format("https://localhost/search.php?search=dish&dish_name={0}", search_nametb.Text.Trim(' ')));
                request.Proxy = null;
                request.Credentials = CredentialCache.DefaultCredentials;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                var responseFromServer = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject obj = Newtonsoft.Json.Linq.JObject.Parse(responseFromServer);
                type_error[] objArr = JsonConvert.DeserializeObject<type_error[]>(obj["type"].ToString());
                foreach (type_error myJsonObj in objArr)
                    error = myJsonObj.error;
                dish_list.Clear();
                if (error != "error")
                {
                    data_dish[] objdata = JsonConvert.DeserializeObject<data_dish[]>(obj["data"].ToString());
                    foreach (data_dish myJsonObj in objdata)
                    {
                        dishes newDish = new dishes();
                        newDish.dname = myJsonObj.dname;
                        newDish.address = myJsonObj.address;
                        newDish.price = myJsonObj.price;
                        newDish.cap = myJsonObj.cap;
                        newDish.restname = myJsonObj.restname;
                        dish_list.Add(newDish);
                    }
                }
            }
            catch (Exception ex)
            {
                error = "error";
                MessageBox.Show(ex.Message);
                Application.Exit();
            }



        }
        private void show_list()
        {
            dish_nametb.Text = dish_list[position].dname;
            addresstb.Text = dish_list[position].address;
            resttb.Text = dish_list[position].restname;
            pricetb.Text = Convert.ToString(dish_list[position].price);
            volumetb.Text = Convert.ToString(dish_list[position].cap);
        }
        private void searchb_Click(object sender, EventArgs e)
        {

            if (search_nametb.Text == "")
            {
                MessageBox.Show("Введите данные для поиска!");
                search_nametb.Text = "";
                search_nametb.Focus();
                return;
            }
            Response_to_server();
            if (error == "error")
            {
                MessageBox.Show("Ничего не найдено");
                search_nametb.Text = "";
                search_nametb.Focus();
                return;
            }
            position = 0;
            refresh();
            show_list();
        }

        private void nextitem_Click(object sender, EventArgs e)
        {
            position++;
            refresh();
            show_list();
        }


        private void previtem_Click(object sender, EventArgs e)
        {
            position--;
            refresh();
            show_list();
        }

        private void firstitem_Click(object sender, EventArgs e)
        {
            position=0;
            refresh();
            show_list();
        }

        private void lastitem_Click(object sender, EventArgs e)
        {
            position = dish_list.Count - 1 ;
            refresh();
            show_list();
        }

        
    }
}
