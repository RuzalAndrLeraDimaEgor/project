﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace Cafe_Project
{
    public partial class pc : Form
    {
        private bool flag = false;
        public pc()
        {
            InitializeComponent();
            initialize_form();
        }

        
        private void initialize_form()
        {
            if (enter.role == "user")
                this.ClientSize = new System.Drawing.Size(327, 405);
            else
                this.ClientSize = new System.Drawing.Size(672, 384);
        }

        private void change_datab_Click(object sender, EventArgs e)
        {
            changedata cdf = new changedata();
            cdf.ShowDialog();
            
        }

        private void orderb_Click(object sender, EventArgs e)
        {
            order of = new order();
            of.ShowDialog();
              
        }

        private void ordersb_Click(object sender, EventArgs e)
        {
            orders osf = new orders();
            osf.ShowDialog();
        }

        private void change_priceb_Click(object sender, EventArgs e)
        {
           change_price cpf = new change_price();
           cpf.ShowDialog();
        }

        private void allordersb_Click(object sender, EventArgs e)
        {
            all_order all_osf = new all_order();
            all_osf.ShowDialog();
        }

        private void statb_Click(object sender, EventArgs e)
        {
            stat sf = new stat();
            sf.Show();
        }

        private void go_to_mainlink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            flag = true;
            this.Close();
            main mf = new main();
            mf.Show();
            
        }

        private void exit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            flag = true;
            main.flag = false;
            enter.role = "";
            enter.session_id = "";
            this.Close();
            main mf = new main();
            mf.Show();
        }


        private void enter_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!flag)
                Application.Exit();
        }
    }
}
