﻿namespace Cafe_Project
{
    partial class add_price
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(add_price));
            this.add_dishb = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.price_tb = new System.Windows.Forms.TextBox();
            this.rest_tb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.namedish = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // add_dishb
            // 
            this.add_dishb.BackgroundImage = global::Cafe_Project.Properties.Resources.button2;
            this.add_dishb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add_dishb.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.add_dishb.FlatAppearance.BorderSize = 2;
            this.add_dishb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_dishb.Font = new System.Drawing.Font("Candara", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.add_dishb.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.add_dishb.Location = new System.Drawing.Point(42, 253);
            this.add_dishb.Name = "add_dishb";
            this.add_dishb.Size = new System.Drawing.Size(355, 41);
            this.add_dishb.TabIndex = 40;
            this.add_dishb.Text = "Добавить";
            this.add_dishb.UseVisualStyleBackColor = true;
            this.add_dishb.Click += new System.EventHandler(this.add_dishb_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(38, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 23);
            this.label4.TabIndex = 39;
            this.label4.Text = "Цена:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(38, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 23);
            this.label3.TabIndex = 38;
            this.label3.Text = "Ресторан:";
            // 
            // price_tb
            // 
            this.price_tb.Location = new System.Drawing.Point(42, 205);
            this.price_tb.Multiline = true;
            this.price_tb.Name = "price_tb";
            this.price_tb.Size = new System.Drawing.Size(355, 32);
            this.price_tb.TabIndex = 2;
            // 
            // rest_tb
            // 
            this.rest_tb.Location = new System.Drawing.Point(42, 144);
            this.rest_tb.Multiline = true;
            this.rest_tb.Name = "rest_tb";
            this.rest_tb.Size = new System.Drawing.Size(355, 32);
            this.rest_tb.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(38, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 23);
            this.label1.TabIndex = 32;
            this.label1.Text = "Блюдо";
            // 
            // namedish
            // 
            this.namedish.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.namedish.FormattingEnabled = true;
            this.namedish.Location = new System.Drawing.Point(42, 84);
            this.namedish.Name = "namedish";
            this.namedish.Size = new System.Drawing.Size(355, 31);
            this.namedish.TabIndex = 0;
            // 
            // add_price
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cafe_Project.Properties.Resources.wall;
            this.ClientSize = new System.Drawing.Size(437, 342);
            this.Controls.Add(this.namedish);
            this.Controls.Add(this.add_dishb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.price_tb);
            this.Controls.Add(this.rest_tb);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Candara", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "add_price";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Добавить в прайс";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button add_dishb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox price_tb;
        private System.Windows.Forms.TextBox rest_tb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox namedish;
    }
}